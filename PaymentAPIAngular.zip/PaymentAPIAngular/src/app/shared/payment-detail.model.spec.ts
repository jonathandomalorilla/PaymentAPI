import { PaymentDetail } from './payment-detail.model';

describe('PaymentDetail', () => {
  it('should create an instance', () => {
    expect(new PaymentDetail()).toBeTruthy();
  });
});

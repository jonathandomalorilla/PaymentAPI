export const environment = {
    apiBaseUrl:'https://localhost:7117/api'
};

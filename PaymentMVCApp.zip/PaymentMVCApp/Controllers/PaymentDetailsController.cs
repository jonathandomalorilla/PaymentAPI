﻿using Microsoft.AspNetCore.Mvc;
using PaymentMvcApp.Services;
using PaymentMvcApp.Models;
using System.Threading.Tasks;

namespace PaymentApp.Controllers
{
    public class PaymentDetailsController : Controller
    {
        private readonly PaymentDetailService _service;

        public PaymentDetailsController(PaymentDetailService service)
        {
            _service = service;
        }

        public async Task<IActionResult> Index()
        {
            var paymentDetails = await _service.GetPaymentDetailsAsync();
            return View(paymentDetails);
        }

        public async Task<IActionResult> Details(int id)
        {
            var paymentDetail = await _service.GetPaymentDetailAsync(id);
            if (paymentDetail == null)
            {
                return NotFound();
            }
            return View(paymentDetail);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PaymentDetailId,CardOwnerName,CardNumber,ExpirationDate,SecurityCode")] PaymentDetail paymentDetail)
        {
            if (ModelState.IsValid)
            {
                await _service.CreatePaymentDetailAsync(paymentDetail);
                return RedirectToAction(nameof(Index));
            }
            return View(paymentDetail);
        }

        public async Task<IActionResult> Edit(int id)
        {
            var paymentDetail = await _service.GetPaymentDetailAsync(id);
            if (paymentDetail == null)
            {
                return NotFound();
            }
            return View(paymentDetail);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PaymentDetailId,CardOwnerName,CardNumber,ExpirationDate,SecurityCode")] PaymentDetail paymentDetail)
        {
            if (id != paymentDetail.PaymentDetailId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                await _service.UpdatePaymentDetailAsync(id, paymentDetail);
                return RedirectToAction(nameof(Index));
            }
            return View(paymentDetail);
        }

        public async Task<IActionResult> Delete(int id)
        {
            var paymentDetail = await _service.GetPaymentDetailAsync(id);
            if (paymentDetail == null)
            {
                return NotFound();
            }
            return View(paymentDetail);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _service.DeletePaymentDetailAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}

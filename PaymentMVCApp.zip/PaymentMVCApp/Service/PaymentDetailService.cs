﻿using PaymentMvcApp.Models;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Collections.Generic;


namespace PaymentMvcApp.Services
{
    public class PaymentDetailService
    {
        private readonly HttpClient _client;

        public PaymentDetailService(HttpClient client)
        {
            _client = client;
        }

        public async Task<IEnumerable<PaymentDetail>> GetPaymentDetailsAsync()
        {
            return await _client.GetFromJsonAsync<IEnumerable<PaymentDetail>>("api/PaymentDetail");
        }

        public async Task<PaymentDetail> GetPaymentDetailAsync(int id)
        {
            return await _client.GetFromJsonAsync<PaymentDetail>($"api/PaymentDetail/{id}");
        }

        public async Task<PaymentDetail> CreatePaymentDetailAsync(PaymentDetail paymentDetail)
        {
            var response = await _client.PostAsJsonAsync("api/PaymentDetail", paymentDetail);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<PaymentDetail>();
        }

        public async Task UpdatePaymentDetailAsync(int id, PaymentDetail paymentDetail)
        {
            var response = await _client.PutAsJsonAsync($"api/PaymentDetail/{id}", paymentDetail);
            response.EnsureSuccessStatusCode();
        }

        public async Task DeletePaymentDetailAsync(int id)
        {
            var response = await _client.DeleteAsync($"api/PaymentDetail/{id}");
            response.EnsureSuccessStatusCode();
        }
    }
}
